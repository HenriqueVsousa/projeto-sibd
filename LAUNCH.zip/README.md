# projeto-sibd

  Plataforma que organiza os sites favoritos.

HOME.PHP :       
        
        weather box; H CHECK
        reminder list scrollable com a sua data limite e com cores conforme a data do reminder; H CHECK
        theme box com os seus sites; R CHECK
        possibilidade de eliminar temas (sites sobrevivem no mapa sem tema associado); R CHECK

	
MAP.PHP (SUN) :
        
       	Adicionar sites a um novo tema ou um já existente; R CHECK
        Colocar limite ao número de temas; R (definir quanditdades de temas que conseguiremos expor no home.php) CHECK
        Adicionar reminder com a descrição e com possibilidade de data de aviso; H CHECK
        hidden option all sections : reminder , weather H CHECK


USER.PHP :       
    
        name, email , password change .... CHECK
	profile picture upload on register.php CHECK
